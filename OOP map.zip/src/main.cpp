#include "raylib.h"
#include "map.h"
#include "player.h"

int main()
{
    InitWindow(600, 750, "OOP PROJECT: THE RADIANT HEIST"); // Perfect Laptop Size
    SetTargetFPS(60);

    CityMap city;
    Player thief(1, 1);

    int score = 0, heistsDone = 0;
    bool isRobbing = false;
    float heistTimer = 0, targetTime = 0;
    const char *jobName = "";

    while (!WindowShouldClose())
    {
        if (!isRobbing)
        {
            Vector2 next = thief.pos;
            bool moveInput = false;
            if (IsKeyPressed(KEY_UP))
            {
                next.y--;
                moveInput = true;
            }
            if (IsKeyPressed(KEY_DOWN))
            {
                next.y++;
                moveInput = true;
            }
            if (IsKeyPressed(KEY_LEFT))
            {
                next.x--;
                moveInput = true;
            }
            if (IsKeyPressed(KEY_RIGHT))
            {
                next.x++;
                moveInput = true;
            }

            if (moveInput && next.x >= 0 && next.x < 20 && next.y >= 0 && next.y < 20)
            {
                int tile = city.grid[(int)next.y][(int)next.x];
                if (tile == STREET || tile == DOOR)
                    thief.Move(next.x - thief.pos.x, next.y - thief.pos.y);
            }
        }

        // Trigger Heist
        if (city.grid[(int)thief.pos.y][(int)thief.pos.x] == DOOR && !isRobbing)
        {
            int bType = city.grid[(int)thief.pos.y - 1][(int)thief.pos.x];
            bool locked = (bType == BANK && heistsDone < 3) || (bType == PRESIDENT && heistsDone < 5);

            if (!locked)
            {
                isRobbing = true;
                heistTimer = 0;
                targetTime = (bType == PRESIDENT) ? 5.0f : (bType == BANK) ? 3.0f
                                                                           : 1.5f;
                jobName = (bType == PRESIDENT) ? "PRESIDENT'S VAULT" : "CITY BANK";
            }
        }

        if (isRobbing)
        {
            heistTimer += GetFrameTime();
            if (heistTimer >= targetTime)
            {
                isRobbing = false;
                heistsDone++;
                score += (targetTime > 4) ? 1000 : 200;
                city.grid[(int)thief.pos.y][(int)thief.pos.x] = STREET;
            }
        }

        BeginDrawing();
        ClearBackground(BLACK);
        city.Draw(heistsDone);
        thief.Draw(30);

        // UI Section
        DrawRectangle(0, 600, 600, 150, DARKGRAY);
        DrawText(TextFormat("SCORE: %05i", score), 20, 620, 30, GOLD);
        DrawText(TextFormat("HEISTS: %i", heistsDone), 20, 660, 20, WHITE);

        if (isRobbing)
        {
            DrawRectangle(250, 630, 300, 30, BLACK);
            DrawRectangle(250, 630, (int)(300 * (heistTimer / targetTime)), 30, LIME);
            DrawText(jobName, 250, 670, 20, RAYWHITE);
        }
        else
        {
            if (heistsDone < 3)
                DrawText("Goal: Rob 3 Buildings to unlock Banks", 250, 640, 18, SKYBLUE);
            else if (heistsDone < 5)
                DrawText("Goal: Rob 2 Banks for President House", 250, 640, 18, YELLOW);
            else
                DrawText("Goal: STEAL FROM THE PRESIDENT!", 250, 640, 18, PURPLE);
        }
        EndDrawing();
    }
    CloseWindow();
    return 0;
}