#ifndef DOOR_H
#define DOOR_H
#include "raylib.h"
#include "Interactable.h"
class Door : public Interactable {
    Rectangle rect;
    bool isOpen;
public:
    Door(float x, float y);
    void draw();
    bool isNear(Vector2 player);
    void interact() override;
};
#endif