#ifndef CCTV_H
#define CCTV_H
#include "raylib.h"
#include "Interactable.h"
class CCTV_Camera : public Interactable {
    Rectangle rect;
public:
    CCTV_Camera(float x, float y);
    void draw();
    bool isNear(Vector2 player);
    void interact() override;
};
#endif