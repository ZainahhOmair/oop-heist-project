#include "raylib.h"
#include "map.h"
#include "player.h"
#include "AlarmSystem.h"
#include "Interactable.h"
#include "Vault.h"
#include "Door.h"
#include "InventoryManager.h"
#include "Item.h"
#include <vector>
#include <iostream>

// =========================================================
// 1. ALARM SYSTEM IMPLEMENTATION
// =========================================================
AlarmSystem* AlarmSystem::instance = nullptr;

AlarmSystem& AlarmSystem::getInstance() {
    if (instance == nullptr) instance = new AlarmSystem();
    return *instance;
}

void AlarmSystem::triggerAlarm() {
    alertLevel++;
    std::cout << "ALARM! Level: " << alertLevel << std::endl;
}

int AlarmSystem::getAlertLevel() const {
    return alertLevel;
}

// =========================================================
// 2. VAULT IMPLEMENTATION
// =========================================================
Vault::Vault(float x, float y, InventoryManager* inv) {
    rect = { x, y, 60, 60 };
    inventory = inv;
}

void Vault::draw() { 
    DrawRectangleRec(rect, GOLD); 
    DrawText("VAULT", (int)rect.x + 5, (int)rect.y + 20, 10, BLACK);
}

bool Vault::isNear(Vector2 playerPos) { 
    return CheckCollisionCircleRec(playerPos, 35, rect); 
}

void Vault::interact() { 
    inventory->addItem(Item("Diamond", 5000)); 
    AlarmSystem::getInstance().triggerAlarm();
}

// =========================================================
// 3. DOOR IMPLEMENTATION
// =========================================================
Door::Door(float x, float y) { 
    rect = { x, y, 40, 80 }; 
    isOpen = false; 
}

void Door::draw() { 
    DrawRectangleRec(rect, isOpen ? GRAY : BROWN); 
    DrawRectangleLinesEx(rect, 2, BLACK);
}

bool Door::isNear(Vector2 playerPos) { 
    return CheckCollisionCircleRec(playerPos, 35, rect); 
}

void Door::interact() { 
    isOpen = !isOpen; 
}

// =========================================================
// MAIN GAME LOOP
// =========================================================
int main() {
    const int screenWidth = 800;
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "NEON HEIST - Final Build");
    SetTargetFPS(60);

    CityMap gameMap;
    robber playerObj(100.0f, 100.0f); 
    InventoryManager playerInventory;
    
    std::vector<Interactable*> props;
    props.push_back(new Door(400, 300));
    props.push_back(new Vault(700, 500, &playerInventory));

    std::vector<police> policeForce;
    policeForce.push_back(police(600, 100));
    policeForce.push_back(police(200, 400));

    while (!WindowShouldClose()) {
        // UPDATE
        playerObj.update(gameMap); 

        bool isAlarmed = AlarmSystem::getInstance().getAlertLevel() > 0;
        for (auto& officer : policeForce) {
            officer.update(playerObj.worldpos, isAlarmed);
            if (CheckCollisionCircles(playerObj.worldpos, 15, officer.worldpos, 20)) {
                playerObj.worldpos = {100, 100}; // Reset if caught
            }
        }

        if (IsKeyPressed(KEY_E)) {
            for (auto prop : props) {
                if (prop->isNear(playerObj.worldpos)) prop->interact();
            }
        }

        // DRAW
        BeginDrawing();
            ClearBackground(BLACK);
            gameMap.Draw(0); 
            for (auto prop : props) prop->draw(); 
            playerObj.Draw(); 
            for (auto& officer : policeForce) officer.Draw(); 

            DrawRectangle(0, 0, screenWidth, 40, Fade(DARKGRAY, 0.8f));
            DrawText(TextFormat("LOOT: $%d", playerInventory.getTotalValue()), 20, 10, 20, GREEN);
            
            if (isAlarmed) DrawText("ALARM TRIPPED!", 320, 10, 20, RED);
            else DrawText("STATUS: STEALTH", 320, 10, 20, RAYWHITE);
        EndDrawing();
    }

    for (auto prop : props) delete prop;
    CloseWindow();
    return 0;
}