#include "Vault.h"
#include "AlarmSystem.h"
#include <iostream>
using namespace std;
Vault::Vault(float x, float y, InventoryManager* inv) {
    rect = {x, y, 50, 50};
    inventory = inv;
}
void Vault::draw() {
    DrawRectangleRec(rect, GOLD);
}
bool Vault::isNear(Vector2 player) {
    return CheckCollisionPointRec(player, rect);
}
void Vault::interact() {
    if (GetRandomValue(0,1)) { // 50% chance to succeed
        inventory->addItem(new Item("Gold", 100)); // add gold item to inventory
        cout << "Vault opened successfully"<<endl;
    } else {
        cout << "Vault failed"<<endl;
        AlarmSystem::getInstance().trigger();
    }
}

bool Vault::isNear(Vector2 &playerPos)
{
    return false;
}
