#include "Door.h"
#include <iostream>
using namespace std;
Door::Door(float x, float y) {
    rect = {x, y, 50, 50};
    isOpen = false;
}
void Door::draw() {
    DrawRectangleRec(rect, isOpen ? GREEN : GRAY);
}
bool Door::isNear(Vector2 player) {
    return CheckCollisionPointRec(player, rect);
}
void Door::interact() {
    isOpen = !isOpen;
    cout << "Door toggled"<<endl;
}