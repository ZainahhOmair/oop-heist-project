#include <iostream>
#include "AlarmSystem.h"
using namespace std;
AlarmSystem* AlarmSystem::instance = nullptr;// singleton pattern implementation
AlarmSystem::AlarmSystem() {
    alertLevel = 0;
}
AlarmSystem& AlarmSystem::getInstance() {
    if (instance == nullptr)//to ensure only one instance exists
        instance = new AlarmSystem();// create instance if it doesn't exist
    return *instance;
}
void AlarmSystem::trigger() {// increase alert level and print message
    alertLevel++;
    cout << "ALARM TRIGGERED! Level: " << alertLevel << endl;
}
int AlarmSystem::getAlertLevel() {
    return alertLevel;
}