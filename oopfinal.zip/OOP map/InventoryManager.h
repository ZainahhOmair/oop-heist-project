#ifndef INVENTORYMANAGER_H
#define INVENTORYMANAGER_H
#include <vector>
#include "Item.h"
using namespace std;
class InventoryManager { // manages collected items
    vector<Item*> items;
public:
    void addItem(Item* item);
    int getTotalValue();
    ~InventoryManager();
};
#endif