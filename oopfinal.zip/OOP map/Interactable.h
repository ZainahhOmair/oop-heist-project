#ifndef INTERACTABLE_H
#define INTERACTABLE_H
class Interactable { // base class for all interactable objects
public:
    virtual void interact() = 0;
};
#endif