#ifndef ALARMSYSTEM_H
#define ALARMSYSTEM_H

class AlarmSystem {
private:
    static AlarmSystem* instance;
    int alertLevel = 0;
    AlarmSystem() {} // Private constructor for Singleton

public:
    static AlarmSystem& getInstance();
    
    // Use 'const' here so the .cpp can match it
    void triggerAlarm(); 
    int getAlertLevel() const; 
};

#endif