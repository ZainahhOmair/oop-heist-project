#ifndef VAULT_H
#define VAULT_H

#include "raylib.h"
#include "Interactable.h"

// Forward Declaration
class InventoryManager; 

class Vault : public Interactable {
private:
    Rectangle rect;
    InventoryManager* inventory; 

public:
    Vault(float x, float y, InventoryManager* inv);
    
    void draw(); 
    
    bool isNear(const Vector2& playerPos) override;
    
    void interact() override;
};

#endif