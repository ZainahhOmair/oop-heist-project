#include <iostream>
#include "AlarmSystem.h"

using namespace std;

AlarmSystem* AlarmSystem::instance = nullptr;

AlarmSystem& AlarmSystem::getInstance() {
    if (instance == nullptr)
        instance = new AlarmSystem();
    return *instance;
}

void AlarmSystem::triggerAlarm() {
    alertLevel++;
    cout << "ALARM TRIGGERED! Level: " << alertLevel << endl;
}

int AlarmSystem::getAlertLevel() const {
    return alertLevel;
}