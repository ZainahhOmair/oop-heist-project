#ifndef ITEM_H
#define ITEM_H
#include <string>
using namespace std;
class Item { // simple item class
    string name;
    int value;
public:
    Item(string n, int v) {
        name = n;
        value = v;
    }
    int getValue() {
        return value;
    }
    string getName() {
        return name;
    }
};
#endif