#ifndef PLAYER_H
#define PLAYER_H

#include "raylib.h"

class Player
{
public:
    Vector2 pos;
    int facing = 0; // 0: Right, 1: Left, 2: Up, 3: Down

    Player(int x, int y) { pos = {(float)x, (float)y}; }

    void Move(int dx, int dy)
    {
        pos.x += dx;
        pos.y += dy;
        if (dx > 0)
            facing = 0;
        else if (dx < 0)
            facing = 1;
        else if (dy < 0)
            facing = 2;
        else if (dy > 0)
            facing = 3;
    }

    void Draw(int tileSize)
    {
        float centerX = pos.x * tileSize + tileSize / 2;
        float centerY = pos.y * tileSize + tileSize / 2;

        // Body
        DrawRectangleV({centerX - 8, centerY - 10}, {16, 20}, DARKGRAY);
        // Mask
        DrawRectangle(centerX - 8, centerY - 6, 16, 6, BLACK);
        // Eyes based on direction
        float ex = (facing == 0) ? 2 : (facing == 1) ? -2
                                                     : 0;
        float ey = (facing == 2) ? -2 : (facing == 3) ? 2
                                                      : 0;
        DrawCircle(centerX - 4 + ex, centerY - 3 + ey, 2, WHITE);
        DrawCircle(centerX + 4 + ex, centerY - 3 + ey, 2, WHITE);
    }
};
#endif