#ifndef MAP_H
#define MAP_H

#include "raylib.h"
#include <vector>
#include <ctime>
#include <cstdlib>

enum TileType
{
    STREET = 0,
    WALL = 1,
    TREES = 2,
    NORMAL = 4,
    DOOR = 5,
    MALL = 6,
    BANK = 7,
    PRESIDENT = 8
};

class CityMap
{
public:
    static const int MAP_SIZE = 20;
    int grid[MAP_SIZE][MAP_SIZE];
    int tileSize = 30; // Shrunk for laptop screens

    CityMap()
    {
        srand(time(0));
        for (int i = 0; i < MAP_SIZE; i++)
        {
            for (int j = 0; j < MAP_SIZE; j++)
            {
                if (i == 0 || i == MAP_SIZE - 1 || j == 0 || j == MAP_SIZE - 1)
                    grid[i][j] = WALL;
                else
                    grid[i][j] = (rand() % 10 > 8) ? TREES : STREET;
            }
        }
        spawnBuilding(PRESIDENT, 1);
        spawnBuilding(BANK, 2);
        spawnBuilding(MALL, 2);
        spawnBuilding(NORMAL, 6);
    }

    void spawnBuilding(int type, int count)
    {
        for (int k = 0; k < count; k++)
        {
            bool placed = false;
            while (!placed)
            {
                int r = rand() % (MAP_SIZE - 4) + 2;
                int c = rand() % (MAP_SIZE - 4) + 2;
                if (grid[r][c] == STREET && (r > 3 || c > 3))
                {
                    grid[r][c] = type;
                    grid[r - 1][c] = type;
                    grid[r][c + 1] = type;
                    grid[r - 1][c + 1] = type;
                    grid[r + 1][c] = DOOR;
                    placed = true;
                }
            }
        }
    }

    void Draw(int heistsDone)
    {
        for (int y = 0; y < MAP_SIZE; y++)
        {
            for (int x = 0; x < MAP_SIZE; x++)
            {
                Vector2 pos = {(float)x * tileSize, (float)y * tileSize};

                // 1. Draw Grass/Roads
                if (grid[y][x] == STREET || grid[y][x] == DOOR)
                {
                    DrawRectangleV(pos, {(float)tileSize, (float)tileSize}, DARKGRAY);
                    if (y % 2 == 0)
                        DrawRectangle(pos.x + 13, pos.y + 8, 4, 15, RAYWHITE); // Road Lines
                }
                else
                {
                    DrawRectangleV(pos, {(float)tileSize, (float)tileSize}, DARKGREEN);
                }

                // 2. Draw Objects
                if (grid[y][x] == WALL)
                    DrawRectangleRec({pos.x, pos.y, (float)tileSize, (float)tileSize}, BLACK);
                else if (grid[y][x] == TREES)
                {
                    DrawRectangle(pos.x + 12, pos.y + 15, 6, 12, BROWN); // Trunk
                    DrawCircle(pos.x + 15, pos.y + 10, 12, LIME);        // Leaves
                }
                else if (grid[y][x] == BANK)
                    DrawBuilding(pos, GOLD, (heistsDone < 3));
                else if (grid[y][x] == MALL)
                    DrawBuilding(pos, ORANGE, false);
                else if (grid[y][x] == PRESIDENT)
                    DrawBuilding(pos, PURPLE, (heistsDone < 5));
                else if (grid[y][x] == NORMAL)
                    DrawBuilding(pos, DARKBLUE, false);
                else if (grid[y][x] == DOOR)
                    DrawRectangleV({pos.x + 8, pos.y + 8}, {14, 14}, MAROON);
            }
        }
    }

    void DrawBuilding(Vector2 pos, Color col, bool locked)
    {
        DrawRectangleV(pos, {(float)tileSize - 2, (float)tileSize - 2}, locked ? GRAY : col);
        // Windows
        DrawRectangle(pos.x + 4, pos.y + 4, 8, 8, SKYBLUE);
        DrawRectangle(pos.x + 18, pos.y + 4, 8, 8, SKYBLUE);
        if (locked)
            DrawText("X", pos.x + 10, pos.y + 8, 15, RED);
    }
};
#endif