#include "CCTV.h"
#include "AlarmSystem.h"
#include <iostream>
using namespace std;
CCTV_Camera::CCTV_Camera(float x, float y) {
    rect = {x, y, 40, 40};
}
void CCTV_Camera::draw() {
    DrawRectangleRec(rect, RED);
}
bool CCTV_Camera::isNear(Vector2 player) {
    return CheckCollisionPointRec(player, rect);
}
void CCTV_Camera::interact() {
    cout << "Camera detected you!!"<<endl;
    AlarmSystem::getInstance().trigger();
}