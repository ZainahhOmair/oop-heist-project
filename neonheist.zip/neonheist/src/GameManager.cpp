#include "GameManager.h"
#include <iostream>
#include <cmath>
using namespace std;

// screen constants - Surface Pro 2880x1920
const int SCREEN_W = 2880;
const int SCREEN_H = 1920;
const int TILE_SIZE = 96;        // 1920 / 20 = 96px per tile
const int MAP_PX = 1920;         // map fills full height = 1920px
const int SIDEBAR_X = 1920;      // sidebar starts after map
const int SIDEBAR_W = 960;       // remaining screen width

// constructor - sets starting values
GameManager::GameManager() : robber(18 * TILE_SIZE, 1 * TILE_SIZE) {
    level = 1;
    gameOver = false;
    gameWon = false;
    alarmActive = false;
}

// sets up each new level
void GameManager::startLevel() {
    policeUnits.clear();
    for (auto t : treasures) delete t;
    treasures.clear();

    alarmActive = false;
    AlarmSystem::getInstance().reset();

    map.regenerate();

    spawnTreasures();
    spawnPolice();
}

// spawns treasures near BANK and PRESIDENT buildings only
void GameManager::spawnTreasures() {
    for (int y = 1; y < CityMap::MAP_SIZE; y++) {
        for (int x = 0; x < CityMap::MAP_SIZE; x++) {
            if (map.grid[y][x] == DOOR) {
                int buildingType = map.grid[y-1][x];
                if (buildingType == BANK || buildingType == PRESIDENT) {
                    treasures.push_back(new Treasure(x, y));
                }
            }
        }
    }
}

// spawns police on random street tiles away from robber
void GameManager::spawnPolice() {
    int policeCount = min(level, 7);
    policeUnits.clear();

    for (int i = 0; i < policeCount; i++) {
        int px, py;
        do {
            px = GetRandomValue(0, CityMap::MAP_SIZE - 1);
            py = GetRandomValue(0, CityMap::MAP_SIZE - 1);
        } while (map.grid[py][px] != STREET ||
                 (abs(px - 18) < 5 && abs(py - 1) < 5)); // stay away from robber spawn

        policeUnits.push_back(Police(px * map.tileSize, py * map.tileSize));
    }
}

// called every frame - updates all game objects
void GameManager::update() {
    if (gameOver || gameWon) return;

    AlarmSystem::getInstance().update(GetFrameTime());
    alarmActive = AlarmSystem::getInstance().isActive();

    robber.update(map);

    for (auto& p : policeUnits) {
        p.update(robber.worldPos, alarmActive, map);
    }

    checkCollisions();
}

// checks all collisions every frame
void GameManager::checkCollisions() {
    // police catches robber = game over
    for (auto& p : policeUnits) {
        float dx = p.worldPos.x - robber.worldPos.x;
        float dy = p.worldPos.y - robber.worldPos.y;
        float distance = sqrt(dx*dx + dy*dy);
        if (distance < 40.0f) {  // increased threshold for bigger tiles
            gameOver = true;
            return;
        }
    }

    // robber touches treasure = collect it
    for (auto t : treasures) {
        if (!t->collected && t->isNear(robber.worldPos, map.tileSize)) {
            t->collected = true;
            inventory.addItem(new Item("Diamond", 100));
            AlarmSystem::getInstance().trigger();
            alarmActive = true;
            cout << "Diamond collected! Alarm triggered!" << endl;
        }
    }

    // all treasures collected = next level
    bool allCollected = true;
    for (auto t : treasures) {
        if (!t->collected) {
            allCollected = false;
            break;
        }
    }

    if (allCollected && !treasures.empty()) {
        level++;
        if (level > 10) {
            gameWon = true;
        } else {
            startLevel();
        }
    }
}

// draws everything on screen
void GameManager::draw() {
    map.Draw(alarmActive);

    for (auto t : treasures) {
        t->Draw(map.tileSize);
    }

    robber.Draw();

    for (auto& p : policeUnits) {
        p.Draw();
    }

    drawUI();

    // red flash when alarm active
    if (alarmActive) {
        DrawRectangle(0, 0, MAP_PX, SCREEN_H, {255, 0, 0, 30});
        DrawText("!! ALARM !!", MAP_PX/2 - 200, 20, 80, RED);
    }

    // game over screen
    if (gameOver) {
        DrawRectangle(0, 0, SCREEN_W, SCREEN_H, {0, 0, 0, 180});
        DrawText("GAME OVER", SCREEN_W/2 - 200, SCREEN_H/2 - 60, 100, RED);
        DrawText("Press R to restart", SCREEN_W/2 - 180, SCREEN_H/2 + 60, 50, WHITE);
    }

    // win screen
    if (gameWon) {
        DrawRectangle(0, 0, SCREEN_W, SCREEN_H, {0, 0, 0, 180});
        DrawText("YOU WIN!", SCREEN_W/2 - 150, SCREEN_H/2 - 60, 100, GREEN);
        DrawText("All heists complete!", SCREEN_W/2 - 220, SCREEN_H/2 + 60, 50, WHITE);
    }
}

// draws the sidebar UI
void GameManager::drawUI() {
    // sidebar background
    DrawRectangle(SIDEBAR_X, 0, SIDEBAR_W, SCREEN_H, BLACK);

    DrawText("NEON HEIST", SIDEBAR_X + 80, 80, 60, YELLOW);
    DrawText(TextFormat("Level: %d / 10", level), SIDEBAR_X + 80, 220, 45, WHITE);

    if (alarmActive) {
        DrawText("ALARM ACTIVE!", SIDEBAR_X + 80, 320, 45, RED);
    } else {
        DrawText("All clear", SIDEBAR_X + 80, 320, 45, GREEN);
    }

    DrawText(TextFormat("Diamonds: %d", inventory.getItemCount()), SIDEBAR_X + 80, 420, 45, SKYBLUE);
    DrawText(TextFormat("Score: %d", inventory.getTotalValue()), SIDEBAR_X + 80, 520, 45, WHITE);

    // controls
    DrawText("WASD to move", SIDEBAR_X + 80, SCREEN_H - 200, 35, GRAY);
    DrawText("Steal from Bank &", SIDEBAR_X + 80, SCREEN_H - 150, 35, GRAY);
    DrawText("President buildings", SIDEBAR_X + 80, SCREEN_H - 100, 35, GRAY);
}

// destructor - cleans up memory
GameManager::~GameManager() {
    for (auto t : treasures) delete t;
    treasures.clear();
}