#ifndef TREASURE_H
#define TREASURE_H

#include "raylib.h"
#include "Map.h"

class Treasure {
public:
    int tileX, tileY;       // position on the grid
    bool collected;          // has robber picked it up?

    Treasure(int x, int y) {
        tileX = x;
        tileY = y;
        collected = false;
    }

    void Draw(int tileSize) {
        if (!collected) {
            // draw a diamond shape using a rotated square
            float centerX = tileX * tileSize + tileSize / 2;
            float centerY = tileY * tileSize + tileSize / 2;
            Rectangle diamond = {centerX, centerY, 12, 12};
            Vector2 origin = {6, 6};
            DrawRectanglePro(diamond, origin, 45, SKYBLUE);   // rotated square = diamond
            DrawRectanglePro(diamond, origin, 45, BLUE);       // outline effect
        }
    }

    bool isNear(Vector2 robberPos, int tileSize) {
        int robberTileX = (int)((robberPos.x + 15) / tileSize);
        int robberTileY = (int)((robberPos.y + 8)  / tileSize);
        return (robberTileX == tileX && robberTileY == tileY);
    }
};

#endif