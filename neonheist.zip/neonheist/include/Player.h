#ifndef PLAYER_H
#define PLAYER_H

#include "raylib.h"
#include "Map.h"
#include <cmath> 

//baseclass
class Player {
    public:
    Vector2 worldPos;  //what is this vector2, and do we have to include vectors too?
    float speed;
    float rotation;
    Color color;

    Player(float x, float y, float s, Color c){
        worldPos = {x, y};
        speed = s;
        color = c;
        rotation = 0.0f;

    }

    virtual void Draw(){ //why did we do it virtually?

        Rectangle shoulders = {worldPos.x, worldPos.y, 30, 15};
        Vector2 origin = {15, 7.5f};
        DrawRectanglePro(shoulders, origin, rotation, color);
        DrawCircleV(worldPos, 8, PINK);  // fixed: worldPos capital P, added semicolon


    }

    virtual ~Player(){}

};
//robber classsssssss
class Robber: public Player {
    public:
    Robber(float x, float y) : Player(x,y,4.0f, PURPLE) {}

    void update(const CityMap& map) {
        Vector2 nextPos = worldPos;  // fixed: nextPos and worldPos capital P

        if (IsKeyDown(KEY_W)) { nextPos.y -= speed; rotation = 270; }
        if (IsKeyDown(KEY_S)) { nextPos.y += speed; rotation = 90;  }
        if (IsKeyDown(KEY_A)) { nextPos.x -= speed; rotation = 180; }
        if (IsKeyDown(KEY_D)) { nextPos.x += speed; rotation = 0;   }

        //need to check the centre of the robber for collision

        int gridX = (int)((nextPos.x + 15) / map.tileSize);
        int gridY = (int)((nextPos.y + 8) / map.tileSize);

        if(map.isWalkable(gridX, gridY)){
            worldPos = nextPos;
        }

    }
};

//police class beedodododooo

enum AIState { PATROL, CHASE}; //how does this work ???

class Police : public Player {
    AIState state;
    float patrolTimer;
    float patrolDx, patrolDy;

    public:
    Police(float x, float y) : Player(x,y,2.5f, BLUE){
        state = PATROL;
        patrolTimer = 0;
        patrolDx = 0;
        patrolDy = 0;
    }

    void update(Vector2 robberPos, bool alarmActive, const CityMap& map){
        if(alarmActive) state = CHASE;
        else state = PATROL;

        Vector2 nextPos = worldPos;

        // need to understand this movement below:

        if(state == CHASE) {
            float dx = robberPos.x - worldPos.x;
            float dy = robberPos.y - worldPos.y;

            if (abs(dx) > abs(dy)) {
                if (dx > 0) { nextPos.x += speed; rotation = 0;   }
                else        { nextPos.x -= speed; rotation = 180; }
            } else {
                if (dy > 0) { nextPos.y += speed; rotation = 90;  }
                else        { nextPos.y -= speed; rotation = 270; }
            }
        }
        else if (state == PATROL) {
            patrolTimer -= GetFrameTime();

            if (patrolTimer <= 0) {
                int dir = GetRandomValue(0, 3);
                patrolDx = 0; patrolDy = 0;
                if (dir == 0) { patrolDx =  speed; rotation = 0;   }
                if (dir == 1) { patrolDx = -speed; rotation = 180; }
                if (dir == 2) { patrolDy =  speed; rotation = 90;  }
                if (dir == 3) { patrolDy = -speed; rotation = 270; }
                patrolTimer = 2.0f;
            }
            // fixed: moved these two lines outside the if(patrolTimer<=0) block
            nextPos.x += patrolDx * GetFrameTime() * 60;
            nextPos.y += patrolDy * GetFrameTime() * 60;
        }

        // fixed: moved collision check outside both if blocks
        int gridX = (int)((nextPos.x + 15) / map.tileSize);
        int gridY = (int)((nextPos.y + 8)  / map.tileSize);

        if (map.isWalkable(gridX, gridY)) {
            worldPos = nextPos;
        } else {
            patrolTimer = 0;
        }
    }

    void Draw() override {
        Rectangle shoulders = {worldPos.x, worldPos.y, 30, 15};
        Vector2 origin = {15, 7.5f};
        DrawRectanglePro(shoulders, origin, rotation, BLUE);
        DrawCircleV(worldPos, 8, DARKBLUE);
    }

};

#endif