#ifndef ALARMSYSTEM_H
#define ALARMSYSTEM_H
#include <iostream>
using namespace std;
class AlarmSystem { // singleton alarm system
private:
    static AlarmSystem* instance;
    int alertLevel;
    AlarmSystem();
public:
    static AlarmSystem& getInstance();
    void trigger();
    int getAlertLevel();
};
#endif