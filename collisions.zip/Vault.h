#ifndef VAULT_H
#define VAULT_H
#include "raylib.h"
#include "Interactable.h"
#include "InventoryManager.h"
class Vault : public Interactable {
    Rectangle rect;
    InventoryManager* inventory;
public:
    Vault(float x, float y, InventoryManager* inv);
    void draw();
    bool isNear(Vector2 player);
    void interact() override;
};
#endif